from cmath import pi
import os
import numpy as np
import funet3 as fn
piso=np.empty([10,4],type(int))
depa=np.empty([10,4],type(int))
ruts=[] #ruts clientes
fn.llenar(piso,depa)
os.system("cls")
op=0
depart=0
suma=0
while(op!=5):
    os.system("cls")
    print("1. Comprar departamento")
    print("2. Mostrar departamentos disponibles")
    print("3. Ver listado de compradores")
    print("4. Mostrar ganancias totales")
    print("5. Salir")
    op=fn.valM()
    if(op==1): #mostrar piso y tipo de depa
        tipo=fn.validaPiso()
        fn.mostrarDisponibles(depa)
        os.system("pause")
        td=fn.tipodepart()
        os.system("pause")
    if(op==2):
        print("*** Disponibilidad de departamentos ***")
        fn.mostrarDisponibles(piso)
        os.system("pause")
    if(op==3):
        fn.Listado(ruts)
        os.system("pause")
    if(op==4):
        suma=0
        suma=fn.totalVendido(depa)
        if(suma==0):
            print("\t No se han vendido departamentos aún")
        else:
            print("\t El total vendido hasta ahora es de : $", suma)
        os.system("pause")
    if(op==5):
        print("Gracias por comprar departamentos con nosotros!!")
        print("Adiós")